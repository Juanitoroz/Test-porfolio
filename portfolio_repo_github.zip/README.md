# Portfolio Livre - Développeur Web

Bienvenue dans mon portfolio interactif sous forme de livre animé.  
Ce projet met en valeur mes compétences en développement web et SEO à travers une interface originale.

## ✨ Contenu
- Portfolio en flipbook avec navigation page par page
- 3 projets présentés
- 3 articles SEO modernes (SEO IA, SEO vocal, SEO local)
- Responsive et léger

## 🚀 Mise en ligne avec GitHub Pages
1. Crée un dépôt public sur [https://github.com](https://github.com)
2. Uploade tous les fichiers de ce dossier (`index.html`, `style.css`, `script.js`, `README.md`)
3. Va dans **Settings > Pages**
4. Dans **Source**, sélectionne `main` et `/root`
5. Clique sur **Save**

Ton site sera en ligne à : `https://<ton-pseudo>.github.io/<nom-du-repo>/`

---

Fait avec ❤️ par [Ton nom]
