const papers = document.querySelectorAll(".paper");
let current = 0;

function goNext() {
  if (current < papers.length) {
    papers[current].classList.add("flipped");
    current++;
  }
}

function goPrev() {
  if (current > 0) {
    current--;
    papers[current].classList.remove("flipped");
  }
}
